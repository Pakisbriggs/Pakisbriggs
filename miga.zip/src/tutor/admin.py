from django.contrib import admin
from tutor.models import Tutor

# Register your models here.
admin.site.register(Tutor)