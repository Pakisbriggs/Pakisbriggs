from django import forms
from help.models import Help 



class CreateHelpForm(forms.ModelForm):

	class Meta:
		model = Help
		fields = ['title', 'body']


class UpdateHelpPostForm(forms.ModelForm):

	class Meta:
		model = Help
		fields = ['title', 'body']

	def save(self, commit=True):
		help_post = self.instance
		help_post.title = self.cleaned_data['title']
		help_post.body = self.cleaned_data['body']


		if commit:
			help_post.save()
		return help_post