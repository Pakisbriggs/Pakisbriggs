from django.shortcuts import render, redirect, get_object_or_404
from help.models import Help
from help.forms import CreateHelpForm, UpdateHelpPostForm
from account.models import Account 
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Create your views here.

context = {}
def help_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	helps = Help.objects.all().order_by('-id')
	page = request.GET.get('page', 1)
	paginator = Paginator(helps, 10)
	try:
		helps = paginator.page(page)
	except PageNotAnInteger:
		helps = paginator.page(1)
	except EmptyPage:
		helps = paginator.page(paginator.num_pages)
	context['helps'] = helps
	return render(request, 'help/help.html', context)


def single_help_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	help_post = get_object_or_404(Help, id=id)

	context['help_post'] = help_post
	return render(request, 'help/single-help.html', context)

def create_help_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	

	form = CreateHelpForm(request.POST or None, request.FILES or None)
	if form.is_valid():
		obj = form.save(commit=False)
		author = Account.objects.filter(email=user.email).first()
		obj.author = author
		obj.save()
		context['success_message'] = "Mystova Created"
		form = CreateHelpForm()
		return redirect('success_help')
	context['form'] = form
	return render(request, 'help/create_help.html', context)

def edit_help_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	help_post = get_object_or_404(Help, id=id)
	if request.POST:
		form = UpdateHelpPostForm(request.POST or None, request.FILES or None, instance=help_post)
		if form.is_valid():
			obj = form.save(commit=False)
			obj.save()
			# context['success_message'] = "Help Update Successful"
			return redirect('success_help_ed')
			help_post = obj
	form = UpdateHelpPostForm(
			initial = {
					"title": help_post.title,
					"body": help_post.body,
			}

		)
	context['form'] = form
	return render(request, 'help/edit_help.html', context)

def delete_help_view(request, id):
	helps = Help.objects.filter(id=id)
	helps.delete()
	return redirect('help')

def success_help(request):
	return render(request, 'help/success_help.html', context)

def success_help_ed(request):
	return render(request, 'help/success_help_edit.html', context)