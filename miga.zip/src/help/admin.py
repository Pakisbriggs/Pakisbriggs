from django.contrib import admin
from help.models import Help

# Register your models here.
admin.site.register(Help)
