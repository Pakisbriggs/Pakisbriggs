from django.urls import path
from help.views import(
	create_help_view,
	edit_help_view,
	delete_help_view,
)

app_name = 'help'


urlpatterns = [
	path('create/', create_help_view, name="create"),
	path('<id>/edit', edit_help_view, name="edit"),
	path('<id>/delete', delete_help_view, name="delete"),
]