from django.shortcuts import render, redirect, get_object_or_404
from account.models import Account
from tutor.forms import UpdateCoursePostForm, UpdateSubjectLinkPostForm
from django.utils.datastructures import MultiValueDictKeyError
from owner.models import Subjects
from swaphearts.models import Swaphistory
from datetime import date
from django.db.models import Avg, Count, Min, Sum

# Create your views here.
context = {}
def manager_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'manager/manager.html', context)

def mark_internship_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	# Check if account is frozeen
	if user.freeze == True:
		return redirect('frozen')
	if user.subject:
		course = Subjects.objects.get(id=user.subject)
		context['course'] = course
	try:
		email = request.POST['email']
		hearts = int(request.POST['hearts'])
	except MultiValueDictKeyError:
		email = "omeco4christ@gmail.com"
		hearts = 0

	mark_post = get_object_or_404(Account, email=email)
	if request.POST:
		form = UpdateCoursePostForm(request.POST or None, request.FILES or None, instance=mark_post)
		if form.is_valid():
			obj = form.save(commit=False)
			if email == user.email:
				return redirect('internship_error')
			author = Account.objects.filter(email=email).first()
			author_hearts = author.hearts
			obj.hearts = hearts + author_hearts
			obj.save()
			sender = Account.objects.filter(email=user.email).first()
			percentage_divide = 10/100
			percentage = percentage_divide * hearts
			sender_hearts = sender.hearts + percentage
			Account.objects.filter(email=user.email).update(hearts= sender_hearts)
			main_admin_email = "pakisbriggs@gmail.com"
			main_admin = Account.objects.filter(email=main_admin_email).first()
			main_admin_percentage_divide = 1/100
			main_admin_percentage = main_admin_percentage_divide * hearts
			main_admin_sender_hearts = main_admin.hearts + main_admin_percentage
			Account.objects.filter(email=main_admin_email).update(hearts= main_admin_sender_hearts)
			now=date.today()
			swaphistory = Swaphistory.objects.create(email=user.email, sender_email=user.email, hearts=percentage, balance=sender_hearts, focus="issued", data_published=now)
			swaphistory_receiver = Swaphistory.objects.create(email=email, sender_email=user.email, hearts=hearts, balance=0, focus="issued", data_published=now)
			swaphistory_admin = Swaphistory.objects.create(email=main_admin_email, sender_email=user.email, hearts=main_admin_percentage, balance=0, focus="issued", data_published=now)
			return redirect('manager')
			# context['success_message'] = "Mark Course Successful"
	return render(request, 'manager/mark_internship.html', context)

def internship_stats_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	swaphistorys = Swaphistory.objects.filter(sender_email=user.email).aggregate(hearts_sum=Sum('hearts'))
	new_swaphistorys = Swaphistory.objects.filter(email=user.email).aggregate(hearts_sum=Sum('hearts'))
	# account_hearts = Account.objects.aggregate(hearts_sum=Sum('hearts'))
	# context['account_hearts'] = account_hearts
	context['swaphistorys'] = swaphistorys
	context['new_swaphistorys'] = new_swaphistorys
	return render(request, 'manager/internship_stats.html', context)


def mark_internship_error(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'manager/mark_internship_error.html', {})
