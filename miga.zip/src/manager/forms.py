from django import forms
from account.models import Account
from owner.models import Subjects  



# class CreateMarkCourseForm(forms.ModelForm):

# 	class Meta:
# 		model = Account
# 		fields = ['email', 'hearts']


# class CreateMarkCourseForm(forms.Form):
#     email= forms.EmailField()
#     hearts = forms.IntegerField()

class UpdateCoursePostForm(forms.ModelForm):

	class Meta:
		model = Account
		fields = ['email', 'hearts']

	def save(self, commit=True):
		mark_post = self.instance
		mark_post.email = self.cleaned_data['email']
		mark_post.hearts = self.cleaned_data['hearts']


		if commit:
			mark_post.save()
		return mark_post


class UpdateSubjectLinkPostForm(forms.ModelForm):

	class Meta:
		model = Subjects
		fields = ['link']

	def save(self, commit=True):
		link_post = self.instance
		link_post.link = self.cleaned_data['link']


		if commit:
			link_post.save()
		return link_post
    