"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include
from django.contrib.auth import views as auth_views
from django.conf.urls.static import static
from django.conf import settings


from personal.views import (
    home_view,
    how_it_works_view,
    be_a_tutor_view,
    t_and_c_view,
)
from account.views import (
    login_view,
    register_view,
    logout_view,
    dashboard_view,
    account_screen_view,
    warning_view,
    success_view,
)

from getskills.views import (
    get_skills_view,
    # subject_view,
    duration_view,
    apply_skills_view,
    internship_view,
    internship_duration_view,
    success_getskills,
    success_applyskills,
)

from swaphearts.views import (
    swaphearts_view,
    swaphistory_view,
    swaphearts_error_view,
    success_swaphearts,
    swaphearts_freeze,
)

from mystovanews.views import (
    mystovanews_view,
    single_news_view,
    success_mystovanews_edit,
    success_mystovanews_create,
)

from globalstat.views import (
    globalstat_view,
)

from help.views import (
    help_view,
    single_help_view,
    success_help,
    success_help_ed,
)

from tutor.views import (
    tutor_view,
    mark_course_view,
    open_admission_view,
    course_stat_view,
    mark_course_error,
    open_admission_success,
)

from manager.views import (
    manager_view,
    mark_internship_view,
    internship_stats_view,
    mark_internship_error,
)

from owner.views import (
    owner_view,
    update_title_view,
    success_create_subject,
)

from roles.views import (
    roles_view,
    success_role,
    success_subject_role,
    success_freeze_user,
)

urlpatterns = [
    path('giant/', admin.site.urls),
    path('', home_view, name="home"),
    path('how_it_works', how_it_works_view, name="how_it_works"),
    path('be_a_tutor', be_a_tutor_view, name="be_a_tutor"),
    path('t_and_cr', t_and_c_view, name="t_and_c"),
    path('login', login_view, name="login"),
    path('register', register_view, name="register"),
    path('dashboard', dashboard_view, name="dashboard"),
    path('account', account_screen_view, name="account"),
    path('warning', warning_view, name="warning"),
    path('logout', logout_view, name="logout"),

    path('owner/', include('owner.urls', 'owner')),
    path('roles/', include('roles.urls', 'roles')),
    path('mystovanews/', include('mystovanews.urls', 'mystovanews')),
    path('help/', include('help.urls', 'help')),
    path('getskills/', include('getskills.urls', 'getskills')),
    path('tinymce/',include('tinymce.urls')), # new


    path('getskills', get_skills_view, name="getskills"),
    # path('subject', subject_view, name="subject"),
    path('duration', duration_view, name="duration"),
    path('apply_skills', apply_skills_view, name="apply_skills"),
    path('internship', internship_view, name="internship"),
    path('internship_duration', internship_duration_view, name="internship_duration"),
    path('swaphearts', swaphearts_view, name="swaphearts"),
    path('swap_history', swaphistory_view, name="swap_history"),
    path('swaphearts_error', swaphearts_error_view, name="swaphearts_error"),
    path('mystovanews', mystovanews_view, name="mystovanews"),
    path('<id>/single_news', single_news_view, name="single_news"),
    path('globalstat', globalstat_view, name="globalstat"),
    path('help', help_view, name="help"),
    path('<id>/single_help', single_help_view, name="single_help"),
    path('tutor', tutor_view, name="tutor"),
    path('mark_course', mark_course_view, name="mark_course"),
    path('course_error', mark_course_error, name="course_error"),
    path('open_admission', open_admission_view, name="open_admission"),
    path('course_stat', course_stat_view, name="course_stat"),
    path('manager', manager_view, name="manager"),
    path('mark_internship', mark_internship_view, name="mark_internship"),
    path('internship_stats', internship_stats_view, name="internship_stats"),
    path('internship_error', mark_internship_error, name="internship_error"),
    path('owner', owner_view, name="owner"),
    path('update_title', update_title_view, name="update_title"),
    path('roles', roles_view, name="roles"),
    path('success', success_view, name="success"),
    path('success_getskills', success_getskills, name="success_getskills"),
    path('success_applyskills', success_applyskills, name="success_applyskills"),
    path('success_swaphearts', success_swaphearts, name="success_swaphearts"),
    path('success_mystovanews_edit', success_mystovanews_edit, name="success_mystovanews_edit"),
    path('success_create_subject', success_create_subject, name="success_create_subject"),
    path('success_role', success_role, name="success_role"),
    path('success_subject_role', success_subject_role, name="success_subject_role"),
    path('success_mystovanews_create', success_mystovanews_create, name="success_mystovanews_create"),
    path('success_help', success_help, name="success_help"),
    path('success_help_ed', success_help_ed, name="success_help_ed"),
    path('open_admission_success', open_admission_success, name="open_admission_success"),
    path('success_freeze', success_freeze_user, name="success_freeze"),
    path('frozen', swaphearts_freeze, name="frozen"),
    





 # Password reset links (ref: https://github.com/django/django/blob/master/django/contrib/auth/views.py)
    path('password_change/done/', auth_views.PasswordChangeDoneView.as_view(template_name='registration/password_change_done.html'), 
        name='password_change_done'),

    path('password_change/', auth_views.PasswordChangeView.as_view(template_name='registration/password_change.html'), 
        name='password_change'),

    path('password_reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_done.html'),
     name='password_reset_done'),

    path('reset/<uidb64>/<token>/', auth_views.PasswordResetConfirmView.as_view(), name='password_reset_confirm'),
    path('password_reset/', auth_views.PasswordResetView.as_view(), name='password_reset'),
    
    path('reset/done/', auth_views.PasswordResetCompleteView.as_view(template_name='registration/password_reset_complete.html'),
     name='password_reset_complete'),
]


handler404 = "mysite.views.page_not_found_view"

if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)