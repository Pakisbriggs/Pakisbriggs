from django.urls import path
from mystovanews.views import(
	mystova_news_view_view,
	mystova_news_create_view,
	mystova_news_detail_view,
	mystova_news_edit_view,
	mystova_news_delete_view,
)

app_name = 'mystovanews'


urlpatterns = [
	path('view/', mystova_news_view_view, name="view"),
	path('create/', mystova_news_create_view, name="create"),
	path('<id>/', mystova_news_detail_view, name="detail"),
	path('<id>/edit', mystova_news_edit_view, name="edit"),
	path('<id>/delete', mystova_news_delete_view, name="delete"),
]