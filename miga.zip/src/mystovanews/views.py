from django.shortcuts import render, redirect, get_object_or_404
from mystovanews.models import Mystovanews
from mystovanews.forms import CreateNewsForm, UpdateNewsPostForm
from account.models import Account 
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Create your views here.
context = {}
def mystovanews_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	mystovanews = Mystovanews.objects.all().order_by('-id')
	page = request.GET.get('page', 1)
	paginator = Paginator(mystovanews, 10)
	try:
		mystovanews = paginator.page(page)
	except PageNotAnInteger:
		mystovanews= paginator.page(1)
	except EmptyPage:
		mystovanews = paginator.page(paginator.num_pages)
	context['mystovanews'] = mystovanews
	return render(request, 'mystovanews/mystovanews.html', context)

def single_news_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	news_post = get_object_or_404(Mystovanews, id=id)

	context['news_post'] = news_post
	return render(request, 'mystovanews/single-news.html', context)

def mystova_news_view_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'mystovanews/view_news.html', context)

def mystova_news_create_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	

	form = CreateNewsForm(request.POST or None, request.FILES or None)
	if form.is_valid():
		obj = form.save(commit=False)
		author = Account.objects.filter(email=user.email).first()
		obj.author = author
		obj.save()
		context['success_message'] = "Mystova Created"
		form = CreateNewsForm()
		return redirect('success_mystovanews_create')
	context['form'] = form
	return render(request, 'mystovanews/create_news.html', context)

def mystova_news_detail_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'mystovanews/detail_news.html', context)

def mystova_news_edit_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	news_post = get_object_or_404(Mystovanews, id=id)
	if request.POST:
		form = UpdateNewsPostForm(request.POST or None, request.FILES or None, instance=news_post)
		if form.is_valid():
			obj = form.save(commit=False)
			obj.save()
			# context['success_message'] = "News Update Successful"
			return redirect('success_mystovanews_edit')
			news_post = obj
	form = UpdateNewsPostForm(
			initial = {
					"title": news_post.title,
					"body": news_post.body,
			}

		)
	context['form'] = form
	return render(request, 'mystovanews/edit_news.html', context)


def mystova_news_delete_view(request, id):
	mystovanews = Mystovanews.objects.filter(id=id)
	mystovanews.delete()
	return redirect('mystovanews')

def success_mystovanews_edit(request):
	return render(request, 'mystovanews/success_mystovanews_edit.html', context)

def success_mystovanews_create(request):
	return render(request, 'mystovanews/success_mystovanews_create.html', context)
