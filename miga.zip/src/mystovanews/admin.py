from django.contrib import admin
from mystovanews.models import Mystovanews

# Register your models here.
admin.site.register(Mystovanews)
