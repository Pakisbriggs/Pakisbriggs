from django import forms
from mystovanews.models import Mystovanews 



class CreateNewsForm(forms.ModelForm):

	class Meta:
		model = Mystovanews
		fields = ['title', 'body']


class UpdateNewsPostForm(forms.ModelForm):

	class Meta:
		model = Mystovanews
		fields = ['title', 'body']

	def save(self, commit=True):
		news_post = self.instance
		news_post.title = self.cleaned_data['title']
		news_post.body = self.cleaned_data['body']


		if commit:
			news_post.save()
		return news_post