from django.contrib import admin
from owner.models import Subjects

# Register your models here.

# admin.site.register(Fields)
admin.site.register(Subjects)
