from django import forms
from owner.models import Subjects 



# class CreateFieldsForm(forms.ModelForm):

# 	class Meta:
# 		model = Fields
# 		fields = ['title']

class CreateSubjectsForm(forms.ModelForm):
	# PROGRAM_DURATION = (
	# 	('1', '1 month'),
	# 	('2', '2months'),
	# 	('3', '3 months'),
	# 	('6', '6 months'),
	# 	('12', '12 months'),
	# 	)

	# program_duration = forms.ChoiceField(choices = PROGRAM_DURATION)

	class Meta:
		model = Subjects
		fields = ['title', 'description', 'area_type', 'program_duration', 'hearts']


# class UpdateFieldsPostForm(forms.ModelForm):

# 	class Meta:
# 		model = Fields
# 		fields = ['title']

# 	def save(self, commit=True):
# 		fields_post = self.instance
# 		fields_post.title = self.cleaned_data['title']


# 		if commit:
# 			fields_post.save()
# 		return fields_post


class UpdateSubjectsPostForm(forms.ModelForm):

	class Meta:
		model = Subjects
		fields = ['title']

	def save(self, commit=True):
		subjects_post = self.instance
		subjects_post.title = self.cleaned_data['title']


		if commit:
			subjects_post.save()
		return subjects_post