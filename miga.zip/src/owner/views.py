from django.shortcuts import render, redirect, get_object_or_404

from owner.models import Subjects
from owner.forms import  CreateSubjectsForm,  UpdateSubjectsPostForm
from account.models import Account 
from tutor.models import Tutor
from mystovanews.models import Mystovanews
from django.db.models import Avg, Count, Min, Sum
from datetime import date

# Create your views here.
context = {}
def owner_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	email = request.user.email
	tutors = Tutor.objects.filter(email=email)
	# news = Mystovanews.objects.all()
	# if news.data_published == date.today():
	# 	flash = "news published now"
	

	context['tutors'] = tutors
	# context['flash'] = flash
	return render(request, 'owner/owner.html', context)

def update_title_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'owner/update_title.html', {})

def create_field_view(request):

	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	
	# fields = Fields.objects.all().order_by('-id')
	# form = CreateFieldsForm(request.POST or None, request.FILES or None)
	# if form.is_valid():
	# 	obj = form.save(commit=False)
	# 	author = Account.objects.filter(email=user.email).first()
	# 	obj.author = author
	# 	obj.save()
	# 	context['success_message'] = "Field Created"
	# 	form = CreateFieldsForm()

	# context['form'] = form
	# context['fields'] = fields
	return render(request, 'owner/create_field.html', context)

def create_subject_view(request):

	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	
	# subjects = Subjects.objects.all().order_by('-id')
	form = CreateSubjectsForm(request.POST or None, request.FILES or None)
	if form.is_valid():
		obj = form.save(commit=False)
		author = Account.objects.filter(email=user.email).first()
		program_duration = form.cleaned_data.get('program_duration') 
		hearts = form.cleaned_data.get('hearts')
		area_type = form.cleaned_data.get('area_type')

		if area_type == 'getskills':
			if program_duration == 1:
				obj.hearts = 200 * 1
			elif program_duration == 2:
				obj.hearts = 200 * 2
			elif program_duration == 3:
				obj.hearts = 200 * 3
			elif program_duration == 6:
				obj.hearts = 200 * 6
			elif program_duration == 12:
				obj.hearts = 200 * 12
			else:
				obj.hearts = 0
		elif area_type == 'applyskills':
			if program_duration == 1:
				obj.hearts = 1000 * 1
			elif program_duration == 2:
				obj.hearts = 1000 * 2
			elif program_duration == 3:
				obj.hearts = 1000 * 3
			elif program_duration == 6:
				obj.hearts = 1000 * 6
			elif program_duration == 12:
				obj.hearts = 1000 * 12
			else:
				obj.hearts = 0

		obj.author = author
		# obj.hearts = hearts
		obj.save()
		# context['success_message'] = "Subject Created"
		return redirect('success_create_subject')
		form = CreateSubjectsForm()

	
	context['form'] = form
	
	return render(request, 'owner/create_subject.html', context)


def fields_detail_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	# fields_post = get_object_or_404(Fields, id=id)

	# context['fields_post'] = fields_post
	return render(request, 'owner/detail_fields.html', context)

def subject_detail_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	subjects_post = get_object_or_404(Subjects, id=id)

	context['subjects_post'] = subjects_post
	return render(request, 'owner/detail_subject.html', context)

def edit_fields_view(request, id):

	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	# fields_post = get_object_or_404(Fields, id=id)
	# if request.POST:
	# 	form = UpdateFieldsPostForm(request.POST or None, request.FILES or None, instance=fields_post)
	# 	if form.is_valid():
	# 		obj = form.save(commit=False)
	# 		obj.save()
	# 		context['success_message'] = "Field Update Successful"
	# 		fields_post = obj
	# form = UpdateFieldsPostForm(
	# 		initial = {
	# 				"title": fields_post.title,
	# 		}

	# 	)
	# context['form'] = form
	return render(request, 'owner/edit_fields.html', context)

def edit_subjects_view(request, id):

	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	subjects_post = get_object_or_404(Subjects, id=id)
	if request.POST:
		form = UpdateSubjectsPostForm(request.POST or None, request.FILES or None, instance=subjects_post)
		if form.is_valid():
			obj = form.save(commit=False)
			obj.save()
			context['success_message'] = "Subject Update Successful"
			subjects_post = obj
	form = UpdateSubjectsPostForm(
			initial = {
					"title": subjects_post.title,
					# "field": subjects_post.field,
			}

		)

	# fields = Fields.objects.all()
	# context['fields'] = fields
	context['form'] = form
	return render(request, 'owner/edit_subjects.html', context)


def delete_fields_view(request, id):
	# fields = Fields.objects.filter(id=id)
	# fields.delete()
	return redirect('update_title')

def delete_subject_view(request, id):
	subjects = Subjects.objects.filter(id=id)
	subjects.delete()
	return redirect('update_title')

def success_create_subject(request):
	return render(request, 'owner/success_create_subject.html', context)
