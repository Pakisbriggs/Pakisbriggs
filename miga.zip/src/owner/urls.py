from django.urls import path
from owner.views import(
	create_field_view,
	create_subject_view,
	fields_detail_view,
	subject_detail_view,
	edit_fields_view,
	edit_subjects_view,
	delete_fields_view,
	delete_subject_view,
	# detail_news_view,
	# edit_news_view,
)

app_name = 'owner'


urlpatterns = [
	path('create_field/', create_field_view, name="create_field"),
	path('create_subject/', create_subject_view, name="create_subject"),
	path('<id>/detail_fields', fields_detail_view, name="detail_fields"),
	path('<id>/detail_subjects', subject_detail_view, name="detail_subjects"),
	path('<id>/edit_fields', edit_fields_view, name="edit_fields"),
	path('<id>/edit_subjects', edit_subjects_view, name="edit_subjects"),
	path('<id>/delete_fields', delete_fields_view, name="delete_fields"),
	path('<id>/delete_subjects', delete_subject_view, name="delete_subjects"),
	# path('<slug>/', detail_news_view, name="detail"),
	# path('<slug>/edit', edit_news_view, name="edit"),
]