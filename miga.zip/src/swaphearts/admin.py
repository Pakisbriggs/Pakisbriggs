from django.contrib import admin
from swaphearts.models import Swaphistory

# Register your models here.
class ItemAdmin(admin.ModelAdmin):
    list_display = ("email", "data_published")
    
admin.site.register(Swaphistory, ItemAdmin)