from django.shortcuts import render, redirect, get_object_or_404
from account.models import Account
from tutor.forms import UpdateCoursePostForm
from django.utils.datastructures import MultiValueDictKeyError
from owner.models import Subjects
from swaphearts.models import Swaphistory
from datetime import date
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger

# Create your views here.
context = {}
def swaphearts_view(request):
	# Check if the user is authenticated
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	# Check if account is frozeen
	if user.freeze == True:
		return redirect('frozen')

	# Check if the user is assigned a subject
	if user.subject:
		course = Subjects.objects.get(id=user.subject)
		context['course'] = course
	try:
		email = request.POST['email']
		hearts = int(request.POST['hearts'])
	except MultiValueDictKeyError:
		email = "omeco4christ@gmail.com"
		hearts = 0
	
	# Get the email that will recieve the heart from the text box
	mark_post = get_object_or_404(Account, email=email)
	if request.POST:
		form = UpdateCoursePostForm(request.POST or None, request.FILES or None, instance=mark_post)
		if form.is_valid():
			obj = form.save(commit=False)
			# Users should not send hearts to themselves. Check if the user wants to send hearts to themselves
			if email == user.email:
				return redirect('swaphearts_error')
			check_sender = Account.objects.filter(email=user.email).first()
			if hearts > check_sender.hearts or hearts < 0:
				return redirect('swaphearts_error')
			author = Account.objects.filter(email=email).first()
			author_hearts = author.hearts
			obj.hearts = hearts + author_hearts
			obj.save()
			sender = Account.objects.filter(email=user.email).first()
			sender_hearts = sender.hearts - hearts
			Account.objects.filter(email=user.email).update(hearts= sender_hearts)
			now=date.today()
			swaphistory = Swaphistory.objects.create(email=user.email, sender_email=user.email, hearts=hearts, balance=sender_hearts, focus="transferred", data_published=now)
			swaphistory_receiver = Swaphistory.objects.create(email=email, sender_email=user.email, hearts=hearts, balance=0, focus="issued",  data_published=now)
			return redirect('success_swaphearts')
			# context['success_message'] = "Mark Course Successful"
	return render(request, 'swaphearts/swaphearts.html', context)

def swaphistory_view(request):
	# Check if user is authenticated
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	# Get email of the authenticated user
	email = request.user.email
	swapheart_historys = Swaphistory.objects.all().order_by('-id')
	page = request.GET.get('page', 1)
	paginator = Paginator(swapheart_historys, 10)
	try:
		swapheart_historys = paginator.page(page)
	except PageNotAnInteger:
		swapheart_historys = paginator.page(1)
	except EmptyPage:
		swapheart_historys = paginator.page(paginator.num_pages)
	context['swapheart_historys'] = swapheart_historys
	return render(request, 'swaphearts/swaphistory.html', context)

def swaphearts_error_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'swaphearts/swaphearts_error.html', {})
def success_swaphearts(request):
	return render(request, 'swaphearts/success_swaphearts.html', context)

def swaphearts_freeze(request):
	return render(request, 'swaphearts/swaphearts_freeze.html', context)


