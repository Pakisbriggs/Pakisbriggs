from django.shortcuts import render
from account.models import Account
from swaphearts.models import Swaphistory
from django.db.models import Avg, Count, Min, Sum
from datetime import date

# Create your views here.
context = {}
def globalstat_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	total_users = Account.objects.count()
	# now=date.today()
	swaphistorys = Swaphistory.objects.filter(focus="issued").aggregate(hearts_sum=Sum('hearts'))
	new_swaphistorys = Swaphistory.objects.filter(focus="transferred").aggregate(hearts_sum=Sum('hearts'))
	account_hearts = Account.objects.aggregate(hearts_sum=Sum('hearts'))
	# sum_of_hearts = swaphistorys.hearts
	
	context['total_users'] = total_users
	context['swaphistorys'] = swaphistorys
	context['new_swaphistorys'] = new_swaphistorys
	context['account_hearts'] = account_hearts
	# context['now'] = now
	return render(request, 'globalstat/globalstat.html', context)
