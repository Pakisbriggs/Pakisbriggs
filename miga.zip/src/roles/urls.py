from django.urls import path
from roles.views import(
	create_user_role_view,
	assign_subject_user_view,
	freeze_user_view,
	edit_user_role_view,
	edit_subject_user_view,
	edit_freeze_user,
	# detail_news_view,
	# edit_news_view,
)

app_name = 'roles'


urlpatterns = [
	path('create', create_user_role_view, name="create"),
	path('subject', assign_subject_user_view, name="subject"),
	path('freeze', freeze_user_view, name="freeze"),
	path('<id>/edit', edit_user_role_view, name="edit"),
	path('<id>/edit_subject', edit_subject_user_view, name="edit_subject"),
	path('<id>/edit_freeze', edit_freeze_user, name="edit_freeze"),
	# path('<slug>/', detail_news_view, name="detail"),
	# path('<slug>/edit', edit_news_view, name="edit"),
]