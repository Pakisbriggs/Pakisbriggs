from django.shortcuts import render, redirect, get_object_or_404
from account.models import Account
from roles.forms import UpdateAccountsPostForm, UpdateAccountsSubjectPostForm, UpdateAccountsFreezePostForm
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from owner.models import Subjects 
from django.db.models import Q
from owner.models import Subjects

# Create your views here.
context = {}
def roles_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'roles/roles.html', {})


def create_user_role_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	accounts = Account.objects.all().order_by('-id')
	page = request.GET.get('page', 1)
	paginator = Paginator(accounts, 20)
	try:
		accounts = paginator.page(page)
	except PageNotAnInteger:
		accounts = paginator.page(1)
	except EmptyPage:
		accounts = paginator.page(paginator.num_pages)
	context['accounts'] = accounts
	return render(request, 'roles/user_role.html', context)

def assign_subject_user_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	account_type1 = Q(account_type="tutor")
	account_type2 = Q(account_type="manager")
	accounts = Account.objects.filter(account_type1).order_by('-id')
	second_accounts = Account.objects.filter(account_type2).order_by('-id')
	subjects = Subjects.objects.all()
	page = request.GET.get('page', 1)
	paginator = Paginator(accounts, 10)
	try:
		accounts = paginator.page(page)
	except PageNotAnInteger:
		accounts = paginator.page(1)
	except EmptyPage:
		accounts = paginator.page(paginator.num_pages)


	second_page = request.GET.get('second_page', 1)
	second_paginator = Paginator(second_accounts, 10)
	try:
		second_accounts = second_paginator.page(second_page)
	except PageNotAnInteger:
		second_accounts = second_paginator.page(1)
	except EmptyPage:
		second_accounts = second_paginator.page(second_paginator.num_pages)

	
	context['second_accounts'] = second_accounts
	context['accounts'] = accounts
	context['subjects'] = subjects
	return render(request, 'roles/assign_subject.html', context)

def edit_user_role_view(request, id):

	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	accounts_post = get_object_or_404(Account, id=id)
	if request.POST:
		form = UpdateAccountsPostForm(request.POST or None, request.FILES or None, instance=accounts_post)
		if form.is_valid():
			obj = form.save(commit=False)
			obj.save()
			# context['success_message'] = "Account Update Successful"
			return redirect('success_role')
			accounts_post = obj
	form = UpdateAccountsPostForm(
			initial = {
					"email": accounts_post.email,

			}

		)
	context['form'] = form
	return render(request, 'roles/user_role_edit.html', context)

def edit_subject_user_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	accounts_subject_post = get_object_or_404(Account, id=id)
	subjects = Subjects.objects.all().order_by('-id')
	role_accounts = Account.objects.filter(id=id)
	if request.POST:
		form = UpdateAccountsSubjectPostForm(request.POST or None, request.FILES or None, instance=accounts_subject_post)
		if form.is_valid():
			obj = form.save(commit=False)
			obj.save()
			# context['success_message'] = "Account Update Successful"
			return redirect('success_subject_role')
			accounts_subject_post = obj
	form = UpdateAccountsSubjectPostForm(
			initial = {
					"email": accounts_subject_post.email,
					"account_type": accounts_subject_post.account_type,
			}

		)
	context['subjects'] = subjects
	context['role_accounts'] = role_accounts
	context['form'] = form
	return render(request, 'roles/assign_subject_edit.html', context)

def success_role(request):
	return render(request, 'roles/success_role.html', context)
def success_subject_role(request):
	return render(request, 'roles/success_subject_role.html', context)

def success_freeze_user(request):
	return render(request, 'roles/success_freeze_user.html', context)

def freeze_user_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	accounts = Account.objects.all().order_by('-id')
	page = request.GET.get('page', 1)
	paginator = Paginator(accounts, 10)
	try:
		accounts = paginator.page(page)
	except PageNotAnInteger:
		accounts = paginator.page(1)
	except EmptyPage:
		accounts = paginator.page(paginator.num_pages)
	context['accounts'] = accounts


	return render(request, 'roles/freeze_user.html', context)

def edit_freeze_user(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	accounts_post = get_object_or_404(Account, id=id)
	if request.POST:
		form = UpdateAccountsFreezePostForm(request.POST or None, request.FILES or None, instance=accounts_post)
		if form.is_valid():
			obj = form.save(commit=False)
			obj.save()
			# context['success_message'] = "Account Update Successful"
			return redirect('success_freeze')
			accounts_post = obj
	form = UpdateAccountsFreezePostForm(
			initial = {
					"email": accounts_post.email,
					"freeze": accounts_post.freeze,

			}

		)
	context['form'] = form
	return render(request, 'roles/edit_freeze_user.html', context)
