from django import forms
from account.models import Account 



class UpdateAccountsPostForm(forms.ModelForm):

	class Meta:
		model = Account
		fields = ['email', 'account_type']

	def save(self, commit=True):
		accounts_post = self.instance
		accounts_post.email = self.cleaned_data['email']
		accounts_post.account_type = self.cleaned_data['account_type']
		
		

		

		if commit:
			accounts_post.save()
		return accounts_post


class UpdateAccountsSubjectPostForm(forms.ModelForm):

	class Meta:
		model = Account
		fields = ['email', 'subject']

	def save(self, commit=True):
		accounts_subject_post = self.instance
		accounts_subject_post.email = self.cleaned_data['email']
		accounts_subject_post.subject = self.cleaned_data['subject']
		
		

		

		if commit:
			accounts_subject_post.save()
		return accounts_subject_post


class UpdateAccountsFreezePostForm(forms.ModelForm):

	class Meta:
		model = Account
		fields = ['email', 'freeze']

	def save(self, commit=True):
		accounts_freeze_post = self.instance
		accounts_freeze_post.email = self.cleaned_data['email']
		accounts_freeze_post.freeze = self.cleaned_data['freeze']
		
		

		

		if commit:
			accounts_freeze_post.save()
		return accounts_freeze_post