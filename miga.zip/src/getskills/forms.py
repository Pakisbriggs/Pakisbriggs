from django import forms
from owner.models import Subjects 



# class CreateNewsForm(forms.ModelForm):

# 	class Meta:
# 		model = Mystovanews
# 		fields = ['title', 'body']


class UpdateSubjectPostForm(forms.ModelForm):

	class Meta:
		model = Subjects
		fields = ['title', 'description', 'area_type', 'program_duration', 'hearts']

	def save(self, commit=True):
		subjects_post = self.instance
		subjects_post.title = self.cleaned_data['title']
		subjects_post.description = self.cleaned_data['description']
		subjects_post.area_type = self.cleaned_data['area_type']
		subjects_post.program_duration = self.cleaned_data['program_duration']
		subjects_post.hearts = self.cleaned_data['hearts']


		if commit:
			subjects_post.save()
		return subjects_post