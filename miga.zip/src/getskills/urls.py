from django.urls import path
from getskills.views import(
	detail_getskills_view,
	edit_getskills_view,
	edit_applyskills_view,
	delete_getskills_view,
	delete_applyskills_view,
	search_getskills,
	search_applyskills,

)

app_name = 'getskills'


urlpatterns = [
	path('search_getskills', search_getskills, name="search_getskills"),
	path('search_applyskills', search_applyskills, name="search_applyskills"),
	path('<id>/getskills', detail_getskills_view, name="getskills_details"),
	path('<id>/edit', edit_getskills_view, name="edit"),
	path('<id>/edit_apply', edit_applyskills_view, name="edit_apply"),
	path('<id>/delete', delete_getskills_view, name="delete"),
	path('<id>/apply', delete_applyskills_view, name="apply"),
]