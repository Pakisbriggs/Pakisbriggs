from django.shortcuts import render, redirect, get_object_or_404
from owner.models import  Subjects
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from getskills.forms import UpdateSubjectPostForm
from account.models import Account
from django.db.models import Q
# from django.urls import resolve

# Create your views here.

context = {}
def get_skills_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	area_type = "getskills"
	subjects = Subjects.objects.filter(area_type=area_type).order_by('-id')
	page = request.GET.get('page', 1)
	paginator = Paginator(subjects, 10)
	try:
		subjects = paginator.page(page)
	except PageNotAnInteger:
		subjects = paginator.page(1)
	except EmptyPage:
		subjects = paginator.page(paginator.num_pages)
	context['subjects'] = subjects
	return render(request, 'getskills/getskills.html', context)

# def subject_view(request):
# 	return render(request, 'getskills/subject.html', {})

def duration_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'getskills/duration.html', {})

def apply_skills_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	area_type = "applyskills"
	subjects = Subjects.objects.filter(area_type=area_type).order_by('-id')
	page = request.GET.get('page', 1)
	paginator = Paginator(subjects, 10)
	try:
		subjects = paginator.page(page)
	except PageNotAnInteger:
		subjects = paginator.page(1)
	except EmptyPage:
		subjects = paginator.page(paginator.num_pages)
	context['subjects'] = subjects
	return render(request, 'getskills/applyskills.html', context)

def internship_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'getskills/internship.html', {})

def internship_duration_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'getskills/internship_duration.html', {})

def detail_getskills_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	getskills_post = get_object_or_404(Subjects, id=id)

	context['getskills_post'] = getskills_post
	return render(request, 'getskills/subject.html', context)

def edit_getskills_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	subjects_post = get_object_or_404(Subjects, id=id)
	if request.POST:
		form = UpdateSubjectPostForm(request.POST or None, request.FILES or None, instance=subjects_post)
		if form.is_valid():
			obj = form.save(commit=False)
			author = Account.objects.filter(email=user.email).first()
			program_duration = form.cleaned_data.get('program_duration')
			hearts = form.cleaned_data.get('hearts')
			area_type = form.cleaned_data.get('area_type')

			if area_type == 'getskills':
				if program_duration == 1:
					obj.hearts = 200 * 1
				elif program_duration == 2:
					obj.hearts = 200 * 2
				elif program_duration == 3:
					obj.hearts = 200 * 3
				elif program_duration == 6:
					obj.hearts = 200 * 6
				elif program_duration == 12:
					obj.hearts = 200 * 12
				else:
					obj.hearts = 0
			elif area_type == 'applyskills':
				if program_duration == 1:
					obj.hearts = 1000 * 1
				elif program_duration == 2:
					obj.hearts = 1000 * 2
				elif program_duration == 3:
					obj.hearts = 1000 * 3
				elif program_duration == 6:
					obj.hearts = 1000 * 6
				elif program_duration == 12:
					obj.hearts = 1000 * 12
				else:
					obj.hearts = 0
			obj.author = author
			obj.save()
			# context['getskills_message'] = "getskills"
			return redirect('success_getskills')
			subjects_post = obj
	form = UpdateSubjectPostForm(
			initial = {
					"title": subjects_post.title,
					"description": subjects_post.description,
					"area_type": subjects_post.area_type,
					"program_duration": subjects_post.program_duration,
					"hearts": subjects_post.hearts,
			}

		)
	context['form'] = form
	return render(request, 'getskills/edit_getskills.html', context)

def edit_applyskills_view(request, id):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	subjects_post = get_object_or_404(Subjects, id=id)
	if request.POST:
		form = UpdateSubjectPostForm(request.POST or None, request.FILES or None, instance=subjects_post)
		if form.is_valid():
			obj = form.save(commit=False)
			author = Account.objects.filter(email=user.email).first()
			program_duration = form.cleaned_data.get('program_duration')
			hearts = form.cleaned_data.get('hearts')
			area_type = form.cleaned_data.get('area_type')

			if area_type == 'getskills':
				if program_duration == 1:
					obj.hearts = 200 * 1
				elif program_duration == 2:
					obj.hearts = 200 * 2
				elif program_duration == 3:
					obj.hearts = 200 * 3
				elif program_duration == 6:
					obj.hearts = 200 * 6
				elif program_duration == 12:
					obj.hearts = 200 * 12
				else:
					obj.hearts = 0
			elif area_type == 'applyskills':
				if program_duration == 1:
					obj.hearts = 1000 * 1
				elif program_duration == 2:
					obj.hearts = 1000 * 2
				elif program_duration == 3:
					obj.hearts = 1000 * 3
				elif program_duration == 6:
					obj.hearts = 1000 * 6
				elif program_duration == 12:
					obj.hearts = 1000 * 12
				else:
					obj.hearts = 0
			obj.author = author
			obj.save()
			# context['success_message'] = "applyskills Update Successful"
			return redirect('success_applyskills')
			subjects_post = obj
	form = UpdateSubjectPostForm(
			initial = {
					"title": subjects_post.title,
					"description": subjects_post.description,
					"area_type": subjects_post.area_type,
					"program_duration": subjects_post.program_duration,
					"hearts": subjects_post.hearts,
			}

		)
	context['form'] = form
	return render(request, 'getskills/edit_applyskills.html', context)

def delete_getskills_view(request, id):
	subjects = Subjects.objects.filter(id=id)
	subjects.delete()
	# current_url = resolve(request.path_info).url_name
	return redirect('getskills')

def delete_applyskills_view(request, id):
	subjects = Subjects.objects.filter(id=id)
	subjects.delete()
	# current_url = resolve(request.path_info).url_name
	return redirect('apply_skills')

def success_getskills(request):
	return render(request, 'getskills/success_getskills.html', context)

def success_applyskills(request):
	return render(request, 'getskills/success_applyskills.html', context)

def search_getskills(request):
	search = request.POST['search']
	area_type = "getskills"
	getskills = Subjects.objects.filter(title__icontains=search).filter(area_type=area_type)
	context['getskills'] = getskills
	return render(request, 'getskills/search_getskills.html', context)

def search_applyskills(request):
	search = request.POST['search']
	area_type = "applyskills"
	applyskills = Subjects.objects.filter(title__icontains=search).filter(area_type=area_type)
	context['applyskills'] = applyskills
	return render(request, 'getskills/search_applyskills.html', context)




	
