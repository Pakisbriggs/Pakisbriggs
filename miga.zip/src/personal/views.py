from django.shortcuts import render
from personal.models import Pagescontent

# Create your views here.
context = {}
def home_view(request):
	homepages = Pagescontent.objects.filter(page="home").order_by('-id')
	context['homepages'] = homepages
	return render(request, 'personal/home.html', context)

def how_it_works_view(request):
	homepages = Pagescontent.objects.filter(page="how_it_works").order_by('-id')
	context['homepages'] = homepages
	return render(request, 'personal/how_it_works.html', context)

def be_a_tutor_view(request):
	homepages = Pagescontent.objects.filter(page="be_a_tutor").order_by('-id')
	context['homepages'] = homepages
	return render(request, 'personal/be_a_tutor.html', context)

def t_and_c_view(request):
	homepages = Pagescontent.objects.filter(page="t_and_c").order_by('-id')
	context['homepages'] = homepages
	return render(request, 'personal/t_and_c.html', context)
