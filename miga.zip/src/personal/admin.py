from django.contrib import admin
from personal.models import Pagescontent


from django.db import models

from tinymce.widgets import TinyMCE


# Register your models here.
class textEditorAdmin(admin.ModelAdmin):

   list_display = ["body"]

   formfield_overrides = {

   models.TextField: {'widget': TinyMCE()}

   }

admin.site.register(Pagescontent, textEditorAdmin)


