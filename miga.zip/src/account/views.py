from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from account.forms import RegistrationForm, AccountAuthenticationForm, AccountUpdateForm

# Create your views here.

def login_view(request):
	context = {}

	user = request.user
	if user.is_authenticated:
		return redirect("home")

	if request.POST:
		form = AccountAuthenticationForm(request.POST)
		if form.is_valid():
			email = request.POST['email']
			password = request.POST['password']
			user = authenticate(email=email, password=password)

			if user:
				login(request, user)
				if user.account_type == "owner":
					return redirect('owner')
				elif user.account_type == "tutor":
					return redirect('tutor')
				elif user.account_type == "manager":
					return redirect('manager')
				elif user.account_type == "customer":
					return redirect('dashboard')


	else:
		form = AccountAuthenticationForm()

	context['login_form'] = form
	return render(request, 'account/login.html', context)

def register_view(request):
	context = {}
	if request.POST:
		form = RegistrationForm(request.POST)
		if form.is_valid():
			terms = form.cleaned_data.get('terms')
			if terms == False:
				return redirect('warning')
			form.save()
			email = form.cleaned_data.get('email')
			raw_password = form.cleaned_data.get('password1')
			account = authenticate(email=email, password=raw_password)
			login(request, account)
			return redirect('dashboard')
		else:
			context['registration_form'] = form
	else:
		form = RegistrationForm()
		context['registration_form'] = form
	return render(request, 'account/register.html', context)

def dashboard_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	return render(request, 'account/dashboard.html', {})

def account_screen_view(request):

	user = request.user
	if not user.is_authenticated:
		return redirect('login')

	context = {}

	if request.POST:
		form = AccountUpdateForm(request.POST, instance=request.user)
		if form.is_valid():
			form.initial = {
				"email": request.POST['email'],
				"username": request.POST['username'],
				"first_name": request.POST['first_name'],
				"last_name": request.POST['last_name'],
				"date_of_birth": request.POST['date_of_birth'],
			}
			form.save()
			# context['success_message'] = "Account Update Successful"
			return redirect('success')
	else:
		form = AccountUpdateForm(
				initial = {
					"email": request.user.email,
					"username": request.user.username,
					"first_name": request.user.first_name,
					"last_name": request.user.last_name,
					"date_of_birth": request.user.date_of_birth,
				}
			)

	context['account_form'] = form
	return render(request, 'account/account.html', context)

def logout_view(request):
	logout(request)
	return redirect('home')

def warning_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'account/warning.html', {})

def success_view(request):
	user = request.user
	if not user.is_authenticated:
		return redirect('login')
	return render(request, 'account/success.html', {})
